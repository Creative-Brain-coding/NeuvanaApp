import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  ScrollView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withRepeat,
  cancelAnimation,
  Easing,
} from 'react-native-reanimated';
import {
  Play,
  Pause,
  RotateCcw,
  Wind,
  Heart,
  Zap,
} from 'lucide-react-native';

const { width, height } = Dimensions.get('window');

interface BreathingTechnique {
  id: string;
  name: string;
  description: string;
  inhale: number;
  hold: number;
  exhale: number;
  icon: React.ReactNode;
  color: string;
}

export default function BreatheScreen() {
  const [selectedTechnique, setSelectedTechnique] = useState<BreathingTechnique | null>(null);
  const [isActive, setIsActive] = useState(false);
  const [currentPhase, setCurrentPhase] = useState<'inhale' | 'hold' | 'exhale'>('inhale');
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [cycleCount, setCycleCount] = useState(0);

  const scale = useSharedValue(1);
  const opacity = useSharedValue(0.7);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const techniques: BreathingTechnique[] = [
    {
      id: '478',
      name: '4-7-8 Technique',
      description: 'Inhale for 4, hold for 7, exhale for 8. Great for anxiety and sleep.',
      inhale: 4,
      hold: 7,
      exhale: 8,
      icon: <Wind size={24} color="#81E6D9" />,
      color: '#81E6D9',
    },
    {
      id: 'box',
      name: 'Box Breathing',
      description: 'Equal counts of 4. Perfect for focus and stress relief.',
      inhale: 4,
      hold: 4,
      exhale: 4,
      icon: <Heart size={24} color="#68D391" />,
      color: '#68D391',
    },
    {
      id: 'energizing',
      name: 'Energizing Breath',
      description: 'Quick inhale, longer exhale. Boosts energy and alertness.',
      inhale: 2,
      hold: 1,
      exhale: 4,
      icon: <Zap size={24} color="#F6AD55" />,
      color: '#F6AD55',
    },
  ];

  const animatedStyle = useAnimatedStyle(() => {
    return {
      transform: [{ scale: scale.value }],
      opacity: opacity.value,
    };
  });

  const startBreathing = () => {
    if (!selectedTechnique) return;

    setIsActive(true);
    setCycleCount(0);
    setCurrentPhase('inhale');
    setTimeRemaining(selectedTechnique.inhale);

    // Start breathing animation
    scale.value = withRepeat(
      withTiming(1.3, {
        duration: (selectedTechnique.inhale + selectedTechnique.hold + selectedTechnique.exhale) * 1000,
        easing: Easing.inOut(Easing.ease),
      }),
      -1,
      true
    );

    opacity.value = withRepeat(
      withTiming(1, {
        duration: (selectedTechnique.inhale + selectedTechnique.hold + selectedTechnique.exhale) * 1000,
        easing: Easing.inOut(Easing.ease),
      }),
      -1,
      true
    );

    // Start breathing cycle timer
    let totalTime = 0;
    const cycleTime = selectedTechnique.inhale + selectedTechnique.hold + selectedTechnique.exhale;

    intervalRef.current = setInterval(() => {
      totalTime += 1;
      const cyclePosition = totalTime % cycleTime;

      if (cyclePosition === 0) {
        setCycleCount(prev => prev + 1);
        setCurrentPhase('inhale');
        setTimeRemaining(selectedTechnique.inhale);
      } else if (cyclePosition === selectedTechnique.inhale) {
        setCurrentPhase('hold');
        setTimeRemaining(selectedTechnique.hold);
      } else if (cyclePosition === selectedTechnique.inhale + selectedTechnique.hold) {
        setCurrentPhase('exhale');
        setTimeRemaining(selectedTechnique.exhale);
      } else {
        setTimeRemaining(prev => prev - 1);
      }
    }, 1000);
  };

  const stopBreathing = () => {
    setIsActive(false);
    cancelAnimation(scale);
    cancelAnimation(opacity);
    scale.value = withTiming(1);
    opacity.value = withTiming(0.7);

    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  };

  const resetBreathing = () => {
    stopBreathing();
    setCycleCount(0);
    setCurrentPhase('inhale');
    setTimeRemaining(0);
  };

  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  const getPhaseText = () => {
    switch (currentPhase) {
      case 'inhale':
        return 'Breathe In';
      case 'hold':
        return 'Hold';
      case 'exhale':
        return 'Breathe Out';
      default:
        return 'Ready';
    }
  };

  const getPhaseColor = () => {
    switch (currentPhase) {
      case 'inhale':
        return '#68D391';
      case 'hold':
        return '#F6AD55';
      case 'exhale':
        return '#81E6D9';
      default:
        return '#CBD5E0';
    }
  };

  if (selectedTechnique) {
    return (
      <LinearGradient colors={['#2D3748', '#4A5568']} style={styles.container}>
        <SafeAreaView style={styles.safeArea}>
          <View style={styles.breathingContainer}>
            {/* Header */}
            <View style={styles.breathingHeader}>
              <TouchableOpacity
                style={styles.backButton}
                onPress={() => setSelectedTechnique(null)}
              >
                <Text style={styles.backButtonText}>← Back</Text>
              </TouchableOpacity>
              <Text style={styles.techniqueName}>{selectedTechnique.name}</Text>
            </View>

            {/* Breathing Circle */}
            <View style={styles.breathingCircleContainer}>
              <Animated.View style={[styles.breathingCircle, animatedStyle]}>
                <LinearGradient
                  colors={[selectedTechnique.color, 'rgba(255,255,255,0.3)']}
                  style={styles.circleGradient}
                >
                  <Text style={styles.phaseText}>{getPhaseText()}</Text>
                  <Text style={styles.countdownText}>{timeRemaining}</Text>
                </LinearGradient>
              </Animated.View>
            </View>

            {/* Stats */}
            <View style={styles.statsContainer}>
              <View style={styles.statItem}>
                <Text style={styles.statNumber}>{cycleCount}</Text>
                <Text style={styles.statLabel}>Cycles</Text>
              </View>
              <View style={styles.statItem}>
                <Text style={[styles.phaseIndicator, { color: getPhaseColor() }]}>
                  {currentPhase.toUpperCase()}
                </Text>
              </View>
            </View>

            {/* Controls */}
            <View style={styles.controlsContainer}>
              <TouchableOpacity
                style={styles.controlButton}
                onPress={resetBreathing}
              >
                <RotateCcw size={24} color="#CBD5E0" />
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.playButton, { backgroundColor: selectedTechnique.color }]}
                onPress={isActive ? stopBreathing : startBreathing}
              >
                {isActive ? (
                  <Pause size={32} color="#2D3748" />
                ) : (
                  <Play size={32} color="#2D3748" />
                )}
              </TouchableOpacity>

              <View style={styles.controlButton} />
            </View>
          </View>
        </SafeAreaView>
      </LinearGradient>
    );
  }

  return (
    <LinearGradient colors={['#2D3748', '#4A5568', '#718096']} style={styles.container}>
      <SafeAreaView style={styles.safeArea}>
        <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
          <View style={styles.header}>
            <Text style={styles.title}>Breathing Exercises</Text>
            <Text style={styles.subtitle}>
              Choose a technique to calm your mind and reduce stress
            </Text>
          </View>

          <View style={styles.techniquesContainer}>
            {techniques.map((technique) => (
              <TouchableOpacity
                key={technique.id}
                style={styles.techniqueCard}
                onPress={() => setSelectedTechnique(technique)}
              >
                <View style={styles.techniqueHeader}>
                  <View style={styles.techniqueIcon}>
                    {technique.icon}
                  </View>
                  <View style={styles.techniqueInfo}>
                    <Text style={styles.techniqueName}>{technique.name}</Text>
                    <Text style={styles.techniquePattern}>
                      {technique.inhale}-{technique.hold}-{technique.exhale}
                    </Text>
                  </View>
                </View>
                <Text style={styles.techniqueDescription}>
                  {technique.description}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <View style={styles.tipsContainer}>
            <Text style={styles.tipsTitle}>Breathing Tips</Text>
            <View style={styles.tipsList}>
              <Text style={styles.tipItem}>• Find a comfortable, quiet space</Text>
              <Text style={styles.tipItem}>• Sit or lie down with your back straight</Text>
              <Text style={styles.tipItem}>• Breathe through your nose when possible</Text>
              <Text style={styles.tipItem}>• Focus on your breath, let thoughts pass</Text>
              <Text style={styles.tipItem}>• Start with 5-10 cycles, build gradually</Text>
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 20,
  },
  header: {
    paddingTop: 20,
    paddingBottom: 30,
  },
  title: {
    fontSize: 32,
    fontFamily: 'Poppins-SemiBold',
    color: '#F7FAFC',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#CBD5E0',
    lineHeight: 24,
  },
  techniquesContainer: {
    gap: 16,
    marginBottom: 30,
  },
  techniqueCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 20,
  },
  techniqueHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  techniqueIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  techniqueInfo: {
    flex: 1,
  },
  techniqueName: {
    fontSize: 18,
    fontFamily: 'Poppins-Medium',
    color: '#F7FAFC',
    marginBottom: 4,
  },
  techniquePattern: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#81E6D9',
  },
  techniqueDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#CBD5E0',
    lineHeight: 20,
  },
  tipsContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 16,
    padding: 20,
    marginBottom: 30,
  },
  tipsTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-Medium',
    color: '#F7FAFC',
    marginBottom: 16,
  },
  tipsList: {
    gap: 8,
  },
  tipItem: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#CBD5E0',
    lineHeight: 20,
  },
  // Breathing session styles
  breathingContainer: {
    flex: 1,
    paddingHorizontal: 20,
  },
  breathingHeader: {
    paddingTop: 20,
    paddingBottom: 30,
    alignItems: 'center',
  },
  backButton: {
    position: 'absolute',
    left: 0,
    top: 20,
  },
  backButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#81E6D9',
  },
  breathingCircleContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  breathingCircle: {
    width: width * 0.7,
    height: width * 0.7,
    borderRadius: (width * 0.7) / 2,
    justifyContent: 'center',
    alignItems: 'center',
  },
  circleGradient: {
    width: '100%',
    height: '100%',
    borderRadius: (width * 0.7) / 2,
    justifyContent: 'center',
    alignItems: 'center',
  },
  phaseText: {
    fontSize: 24,
    fontFamily: 'Poppins-Medium',
    color: '#2D3748',
    marginBottom: 8,
  },
  countdownText: {
    fontSize: 48,
    fontFamily: 'Poppins-SemiBold',
    color: '#2D3748',
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    paddingVertical: 30,
  },
  statItem: {
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 32,
    fontFamily: 'Poppins-SemiBold',
    color: '#F7FAFC',
  },
  statLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#CBD5E0',
    marginTop: 4,
  },
  phaseIndicator: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    letterSpacing: 2,
  },
  controlsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingBottom: 40,
  },
  controlButton: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  playButton: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
});