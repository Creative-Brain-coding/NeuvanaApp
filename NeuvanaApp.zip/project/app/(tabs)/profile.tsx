import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Switch,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { User, Bell, Moon, Shield, CircleHelp as HelpCircle, Heart, Award, Calendar, TrendingUp, Settings, Phone, ExternalLink } from 'lucide-react-native';

interface UserStats {
  totalSessions: number;
  daysActive: number;
  journalEntries: number;
  breathingMinutes: number;
  currentStreak: number;
}

interface UserSettings {
  notifications: boolean;
  darkMode: boolean;
  reminderTime: string;
  soundEnabled: boolean;
}

export default function ProfileScreen() {
  const [userStats, setUserStats] = useState<UserStats>({
    totalSessions: 0,
    daysActive: 0,
    journalEntries: 0,
    breathingMinutes: 0,
    currentStreak: 0,
  });

  const [settings, setSettings] = useState<UserSettings>({
    notifications: true,
    darkMode: true,
    reminderTime: '9:00 AM',
    soundEnabled: true,
  });

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    try {
      // Load journal entries to calculate stats
      const journalEntries = await AsyncStorage.getItem('journal_entries');
      const entries = journalEntries ? JSON.parse(journalEntries) : [];
      
      // Calculate stats (simplified for demo)
      const stats: UserStats = {
        totalSessions: 24,
        daysActive: 12,
        journalEntries: entries.length,
        breathingMinutes: 180,
        currentStreak: 5,
      };

      setUserStats(stats);

      // Load settings
      const savedSettings = await AsyncStorage.getItem('user_settings');
      if (savedSettings) {
        setSettings(JSON.parse(savedSettings));
      }
    } catch (error) {
      console.error('Error loading user data:', error);
    }
  };

  const saveSettings = async (newSettings: UserSettings) => {
    try {
      await AsyncStorage.setItem('user_settings', JSON.stringify(newSettings));
      setSettings(newSettings);
    } catch (error) {
      console.error('Error saving settings:', error);
    }
  };

  const toggleSetting = (key: keyof UserSettings) => {
    const newSettings = { ...settings, [key]: !settings[key] };
    saveSettings(newSettings);
  };

  const showCrisisResources = () => {
    Alert.alert(
      'Crisis Resources',
      'If you\'re experiencing a mental health crisis, please reach out for help:\n\n' +
      '• National Suicide Prevention Lifeline: 988\n' +
      '• Crisis Text Line: Text HOME to 741741\n' +
      '• Emergency Services: 911\n\n' +
      'You are not alone. Help is available 24/7.',
      [
        { text: 'Call 988', onPress: () => {} },
        { text: 'Close', style: 'cancel' },
      ]
    );
  };

  const achievements = [
    { id: 1, title: 'First Steps', description: 'Completed your first session', earned: true },
    { id: 2, title: 'Mindful Week', description: '7 days of consistent practice', earned: true },
    { id: 3, title: 'Journal Keeper', description: 'Written 10 journal entries', earned: userStats.journalEntries >= 10 },
    { id: 4, title: 'Breathing Master', description: '60 minutes of breathing exercises', earned: userStats.breathingMinutes >= 60 },
    { id: 5, title: 'Streak Champion', description: '30-day practice streak', earned: false },
  ];

  const earnedAchievements = achievements.filter(a => a.earned);

  return (
    <LinearGradient colors={['#2D3748', '#4A5568', '#718096']} style={styles.container}>
      <SafeAreaView style={styles.safeArea}>
        <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
          {/* Header */}
          <View style={styles.header}>
            <View style={styles.profileSection}>
              <View style={styles.avatarContainer}>
                <LinearGradient
                  colors={['#81E6D9', '#68D391']}
                  style={styles.avatar}
                >
                  <User size={32} color="#2D3748" />
                </LinearGradient>
              </View>
              <View style={styles.profileInfo}>
                <Text style={styles.userName}>Welcome back!</Text>
                <Text style={styles.userSubtitle}>Your wellness journey</Text>
              </View>
            </View>
          </View>

          {/* Stats Overview */}
          <View style={styles.statsContainer}>
            <Text style={styles.sectionTitle}>Your Progress</Text>
            <View style={styles.statsGrid}>
              <View style={styles.statCard}>
                <Calendar size={20} color="#81E6D9" />
                <Text style={styles.statNumber}>{userStats.daysActive}</Text>
                <Text style={styles.statLabel}>Days Active</Text>
              </View>
              <View style={styles.statCard}>
                <TrendingUp size={20} color="#68D391" />
                <Text style={styles.statNumber}>{userStats.totalSessions}</Text>
                <Text style={styles.statLabel}>Sessions</Text>
              </View>
              <View style={styles.statCard}>
                <Heart size={20} color="#F56565" />
                <Text style={styles.statNumber}>{userStats.currentStreak}</Text>
                <Text style={styles.statLabel}>Day Streak</Text>
              </View>
            </View>
          </View>

          {/* Achievements */}
          <View style={styles.achievementsContainer}>
            <Text style={styles.sectionTitle}>Achievements</Text>
            <ScrollView 
              horizontal 
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.achievementsScroll}
            >
              {achievements.map((achievement) => (
                <View
                  key={achievement.id}
                  style={[
                    styles.achievementCard,
                    !achievement.earned && styles.achievementCardLocked
                  ]}
                >
                  <Award 
                    size={24} 
                    color={achievement.earned ? '#F6AD55' : '#A0AEC0'} 
                  />
                  <Text style={[
                    styles.achievementTitle,
                    !achievement.earned && styles.achievementTitleLocked
                  ]}>
                    {achievement.title}
                  </Text>
                  <Text style={[
                    styles.achievementDescription,
                    !achievement.earned && styles.achievementDescriptionLocked
                  ]}>
                    {achievement.description}
                  </Text>
                </View>
              ))}
            </ScrollView>
          </View>

          {/* Settings */}
          <View style={styles.settingsContainer}>
            <Text style={styles.sectionTitle}>Settings</Text>
            
            <View style={styles.settingItem}>
              <View style={styles.settingInfo}>
                <Bell size={20} color="#81E6D9" />
                <View style={styles.settingText}>
                  <Text style={styles.settingTitle}>Notifications</Text>
                  <Text style={styles.settingSubtitle}>Daily reminders and encouragement</Text>
                </View>
              </View>
              <Switch
                value={settings.notifications}
                onValueChange={() => toggleSetting('notifications')}
                trackColor={{ false: '#4A5568', true: '#81E6D9' }}
                thumbColor={settings.notifications ? '#2D3748' : '#CBD5E0'}
              />
            </View>

            <View style={styles.settingItem}>
              <View style={styles.settingInfo}>
                <Moon size={20} color="#9F7AEA" />
                <View style={styles.settingText}>
                  <Text style={styles.settingTitle}>Dark Mode</Text>
                  <Text style={styles.settingSubtitle}>Easier on the eyes</Text>
                </View>
              </View>
              <Switch
                value={settings.darkMode}
                onValueChange={() => toggleSetting('darkMode')}
                trackColor={{ false: '#4A5568', true: '#81E6D9' }}
                thumbColor={settings.darkMode ? '#2D3748' : '#CBD5E0'}
              />
            </View>

            <TouchableOpacity style={styles.settingItem}>
              <View style={styles.settingInfo}>
                <Settings size={20} color="#68D391" />
                <View style={styles.settingText}>
                  <Text style={styles.settingTitle}>Reminder Time</Text>
                  <Text style={styles.settingSubtitle}>{settings.reminderTime}</Text>
                </View>
              </View>
              <ExternalLink size={16} color="#A0AEC0" />
            </TouchableOpacity>
          </View>

          {/* Support & Resources */}
          <View style={styles.supportContainer}>
            <Text style={styles.sectionTitle}>Support & Resources</Text>
            
            <TouchableOpacity style={styles.supportItem} onPress={showCrisisResources}>
              <View style={styles.supportInfo}>
                <Phone size={20} color="#FC8181" />
                <View style={styles.supportText}>
                  <Text style={styles.supportTitle}>Crisis Resources</Text>
                  <Text style={styles.supportSubtitle}>24/7 mental health support</Text>
                </View>
              </View>
              <ExternalLink size={16} color="#A0AEC0" />
            </TouchableOpacity>

            <TouchableOpacity style={styles.supportItem}>
              <View style={styles.supportInfo}>
                <HelpCircle size={20} color="#F6AD55" />
                <View style={styles.supportText}>
                  <Text style={styles.supportTitle}>Help & FAQ</Text>
                  <Text style={styles.supportSubtitle}>Get answers to common questions</Text>
                </View>
              </View>
              <ExternalLink size={16} color="#A0AEC0" />
            </TouchableOpacity>

            <TouchableOpacity style={styles.supportItem}>
              <View style={styles.supportInfo}>
                <Shield size={20} color="#68D391" />
                <View style={styles.supportText}>
                  <Text style={styles.supportTitle}>Privacy Policy</Text>
                  <Text style={styles.supportSubtitle}>How we protect your data</Text>
                </View>
              </View>
              <ExternalLink size={16} color="#A0AEC0" />
            </TouchableOpacity>
          </View>

          {/* App Info */}
          <View style={styles.appInfoContainer}>
            <Text style={styles.appVersion}>Neuvana v1.0.0</Text>
            <Text style={styles.appDescription}>
              Your companion for mental wellness and mindfulness
            </Text>
          </View>
        </ScrollView>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 20,
  },
  header: {
    paddingTop: 20,
    paddingBottom: 30,
  },
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatarContainer: {
    marginRight: 16,
  },
  avatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 24,
    fontFamily: 'Poppins-SemiBold',
    color: '#F7FAFC',
    marginBottom: 4,
  },
  userSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#CBD5E0',
  },
  statsContainer: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Poppins-Medium',
    color: '#F7FAFC',
    marginBottom: 16,
  },
  statsGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 24,
    fontFamily: 'Poppins-SemiBold',
    color: '#F7FAFC',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#CBD5E0',
    marginTop: 4,
  },
  achievementsContainer: {
    marginBottom: 30,
  },
  achievementsScroll: {
    paddingRight: 20,
  },
  achievementCard: {
    width: 140,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    marginRight: 12,
  },
  achievementCardLocked: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
  },
  achievementTitle: {
    fontSize: 14,
    fontFamily: 'Poppins-Medium',
    color: '#F7FAFC',
    marginTop: 8,
    textAlign: 'center',
  },
  achievementTitleLocked: {
    color: '#A0AEC0',
  },
  achievementDescription: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#CBD5E0',
    marginTop: 4,
    textAlign: 'center',
    lineHeight: 16,
  },
  achievementDescriptionLocked: {
    color: '#718096',
  },
  settingsContainer: {
    marginBottom: 30,
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
  },
  settingInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingText: {
    marginLeft: 16,
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
    color: '#F7FAFC',
    marginBottom: 2,
  },
  settingSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#CBD5E0',
  },
  supportContainer: {
    marginBottom: 30,
  },
  supportItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
  },
  supportInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  supportText: {
    marginLeft: 16,
    flex: 1,
  },
  supportTitle: {
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
    color: '#F7FAFC',
    marginBottom: 2,
  },
  supportSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#CBD5E0',
  },
  appInfoContainer: {
    alignItems: 'center',
    paddingVertical: 30,
  },
  appVersion: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#81E6D9',
    marginBottom: 8,
  },
  appDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#A0AEC0',
    textAlign: 'center',
  },
});