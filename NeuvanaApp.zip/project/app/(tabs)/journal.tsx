import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Modal,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Plus, Calendar, Heart, Smile, Meh, Frown, CreditCard as Edit3, Trash2, BookOpen } from 'lucide-react-native';

interface JournalEntry {
  id: string;
  date: string;
  mood: 'happy' | 'neutral' | 'sad';
  title: string;
  content: string;
  gratitude: string[];
  timestamp: number;
}

interface MoodStats {
  happy: number;
  neutral: number;
  sad: number;
  total: number;
}

export default function JournalScreen() {
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [editingEntry, setEditingEntry] = useState<JournalEntry | null>(null);
  const [selectedMood, setSelectedMood] = useState<'happy' | 'neutral' | 'sad'>('happy');
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [gratitudeItems, setGratitudeItems] = useState<string[]>(['', '', '']);
  const [moodStats, setMoodStats] = useState<MoodStats>({ happy: 0, neutral: 0, sad: 0, total: 0 });

  const moodOptions = [
    { mood: 'happy' as const, icon: Smile, color: '#68D391', label: 'Great' },
    { mood: 'neutral' as const, icon: Meh, color: '#F6AD55', label: 'Okay' },
    { mood: 'sad' as const, icon: Frown, color: '#FC8181', label: 'Tough' },
  ];

  const gratitudePrompts = [
    "What made you smile today?",
    "Who are you grateful for?",
    "What small moment brought you joy?",
  ];

  useEffect(() => {
    loadEntries();
  }, []);

  useEffect(() => {
    calculateMoodStats();
  }, [entries]);

  const loadEntries = async () => {
    try {
      const storedEntries = await AsyncStorage.getItem('journal_entries');
      if (storedEntries) {
        const parsed = JSON.parse(storedEntries);
        setEntries(parsed.sort((a: JournalEntry, b: JournalEntry) => b.timestamp - a.timestamp));
      }
    } catch (error) {
      console.error('Error loading entries:', error);
    }
  };

  const saveEntries = async (newEntries: JournalEntry[]) => {
    try {
      await AsyncStorage.setItem('journal_entries', JSON.stringify(newEntries));
    } catch (error) {
      console.error('Error saving entries:', error);
    }
  };

  const calculateMoodStats = () => {
    const stats = entries.reduce(
      (acc, entry) => {
        acc[entry.mood]++;
        acc.total++;
        return acc;
      },
      { happy: 0, neutral: 0, sad: 0, total: 0 }
    );
    setMoodStats(stats);
  };

  const openModal = (entry?: JournalEntry) => {
    if (entry) {
      setEditingEntry(entry);
      setSelectedMood(entry.mood);
      setTitle(entry.title);
      setContent(entry.content);
      setGratitudeItems([...entry.gratitude, '', '', ''].slice(0, 3));
    } else {
      setEditingEntry(null);
      setSelectedMood('happy');
      setTitle('');
      setContent('');
      setGratitudeItems(['', '', '']);
    }
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditingEntry(null);
    setTitle('');
    setContent('');
    setGratitudeItems(['', '', '']);
  };

  const saveEntry = () => {
    if (!title.trim() && !content.trim()) {
      Alert.alert('Empty Entry', 'Please add a title or some content to your journal entry.');
      return;
    }

    const now = new Date();
    const entry: JournalEntry = {
      id: editingEntry?.id || Date.now().toString(),
      date: now.toLocaleDateString(),
      mood: selectedMood,
      title: title.trim() || 'Untitled Entry',
      content: content.trim(),
      gratitude: gratitudeItems.filter(item => item.trim() !== ''),
      timestamp: editingEntry?.timestamp || now.getTime(),
    };

    let newEntries;
    if (editingEntry) {
      newEntries = entries.map(e => e.id === entry.id ? entry : e);
    } else {
      newEntries = [entry, ...entries];
    }

    setEntries(newEntries);
    saveEntries(newEntries);
    closeModal();
  };

  const deleteEntry = (entryId: string) => {
    Alert.alert(
      'Delete Entry',
      'Are you sure you want to delete this journal entry?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            const newEntries = entries.filter(e => e.id !== entryId);
            setEntries(newEntries);
            saveEntries(newEntries);
          },
        },
      ]
    );
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    } else if (date.toDateString() === yesterday.toDateString()) {
      return 'Yesterday';
    } else {
      return date.toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric',
        year: date.getFullYear() !== today.getFullYear() ? 'numeric' : undefined
      });
    }
  };

  return (
    <LinearGradient colors={['#2D3748', '#4A5568', '#718096']} style={styles.container}>
      <SafeAreaView style={styles.safeArea}>
        <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
          {/* Header */}
          <View style={styles.header}>
            <View style={styles.headerTop}>
              <View>
                <Text style={styles.title}>Journal</Text>
                <Text style={styles.subtitle}>Reflect on your thoughts and feelings</Text>
              </View>
              <TouchableOpacity
                style={styles.addButton}
                onPress={() => openModal()}
              >
                <Plus size={24} color="#2D3748" />
              </TouchableOpacity>
            </View>
          </View>

          {/* Mood Stats */}
          {moodStats.total > 0 && (
            <View style={styles.statsContainer}>
              <Text style={styles.statsTitle}>This Week's Mood</Text>
              <View style={styles.statsGrid}>
                {moodOptions.map(({ mood, icon: Icon, color, label }) => {
                  const percentage = moodStats.total > 0 ? (moodStats[mood] / moodStats.total) * 100 : 0;
                  return (
                    <View key={mood} style={styles.statCard}>
                      <Icon size={20} color={color} />
                      <Text style={styles.statPercentage}>{Math.round(percentage)}%</Text>
                      <Text style={styles.statLabel}>{label}</Text>
                    </View>
                  );
                })}
              </View>
            </View>
          )}

          {/* Journal Entries */}
          <View style={styles.entriesContainer}>
            <Text style={styles.sectionTitle}>Your Entries</Text>
            {entries.length === 0 ? (
              <View style={styles.emptyState}>
                <BookOpen size={48} color="#A0AEC0" />
                <Text style={styles.emptyStateTitle}>No entries yet</Text>
                <Text style={styles.emptyStateText}>
                  Start your mindfulness journey by writing your first journal entry
                </Text>
                <TouchableOpacity
                  style={styles.emptyStateButton}
                  onPress={() => openModal()}
                >
                  <Text style={styles.emptyStateButtonText}>Write First Entry</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <View style={styles.entriesList}>
                {entries.map((entry) => {
                  const moodOption = moodOptions.find(m => m.mood === entry.mood);
                  return (
                    <TouchableOpacity
                      key={entry.id}
                      style={styles.entryCard}
                      onPress={() => openModal(entry)}
                    >
                      <View style={styles.entryHeader}>
                        <View style={styles.entryMood}>
                          {moodOption && React.createElement(moodOption.icon, {
                            size: 20,
                            color: moodOption.color
                          })}
                          <Text style={styles.entryDate}>{formatDate(entry.date)}</Text>
                        </View>
                        <TouchableOpacity
                          style={styles.deleteButton}
                          onPress={() => deleteEntry(entry.id)}
                        >
                          <Trash2 size={16} color="#FC8181" />
                        </TouchableOpacity>
                      </View>
                      <Text style={styles.entryTitle}>{entry.title}</Text>
                      {entry.content && (
                        <Text style={styles.entryContent} numberOfLines={2}>
                          {entry.content}
                        </Text>
                      )}
                      {entry.gratitude.length > 0 && (
                        <View style={styles.gratitudePreview}>
                          <Heart size={14} color="#F56565" />
                          <Text style={styles.gratitudeText}>
                            {entry.gratitude.length} gratitude note{entry.gratitude.length !== 1 ? 's' : ''}
                          </Text>
                        </View>
                      )}
                    </TouchableOpacity>
                  );
                })}
              </View>
            )}
          </View>
        </ScrollView>

        {/* Journal Entry Modal */}
        <Modal
          visible={showModal}
          animationType="slide"
          presentationStyle="pageSheet"
        >
          <LinearGradient colors={['#2D3748', '#4A5568']} style={styles.modalContainer}>
            <SafeAreaView style={styles.modalSafeArea}>
              <View style={styles.modalHeader}>
                <TouchableOpacity onPress={closeModal}>
                  <Text style={styles.modalCancelText}>Cancel</Text>
                </TouchableOpacity>
                <Text style={styles.modalTitle}>
                  {editingEntry ? 'Edit Entry' : 'New Entry'}
                </Text>
                <TouchableOpacity onPress={saveEntry}>
                  <Text style={styles.modalSaveText}>Save</Text>
                </TouchableOpacity>
              </View>

              <ScrollView style={styles.modalContent} showsVerticalScrollIndicator={false}>
                {/* Mood Selection */}
                <View style={styles.modalSection}>
                  <Text style={styles.modalSectionTitle}>How are you feeling?</Text>
                  <View style={styles.moodSelector}>
                    {moodOptions.map(({ mood, icon: Icon, color, label }) => (
                      <TouchableOpacity
                        key={mood}
                        style={[
                          styles.moodOption,
                          selectedMood === mood && styles.moodOptionSelected
                        ]}
                        onPress={() => setSelectedMood(mood)}
                      >
                        <Icon size={24} color={selectedMood === mood ? '#2D3748' : color} />
                        <Text style={[
                          styles.moodOptionText,
                          selectedMood === mood && styles.moodOptionTextSelected
                        ]}>
                          {label}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>

                {/* Title Input */}
                <View style={styles.modalSection}>
                  <Text style={styles.modalSectionTitle}>Title</Text>
                  <TextInput
                    style={styles.titleInput}
                    placeholder="Give your entry a title..."
                    placeholderTextColor="#A0AEC0"
                    value={title}
                    onChangeText={setTitle}
                  />
                </View>

                {/* Content Input */}
                <View style={styles.modalSection}>
                  <Text style={styles.modalSectionTitle}>Your thoughts</Text>
                  <TextInput
                    style={styles.contentInput}
                    placeholder="What's on your mind today?"
                    placeholderTextColor="#A0AEC0"
                    value={content}
                    onChangeText={setContent}
                    multiline
                    textAlignVertical="top"
                  />
                </View>

                {/* Gratitude Section */}
                <View style={styles.modalSection}>
                  <Text style={styles.modalSectionTitle}>Gratitude</Text>
                  <Text style={styles.modalSectionSubtitle}>
                    What are you grateful for today?
                  </Text>
                  {gratitudePrompts.map((prompt, index) => (
                    <View key={index} style={styles.gratitudeItem}>
                      <Text style={styles.gratitudePrompt}>{prompt}</Text>
                      <TextInput
                        style={styles.gratitudeInput}
                        placeholder="Type your answer..."
                        placeholderTextColor="#A0AEC0"
                        value={gratitudeItems[index]}
                        onChangeText={(text) => {
                          const newItems = [...gratitudeItems];
                          newItems[index] = text;
                          setGratitudeItems(newItems);
                        }}
                      />
                    </View>
                  ))}
                </View>
              </ScrollView>
            </SafeAreaView>
          </LinearGradient>
        </Modal>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 20,
  },
  header: {
    paddingTop: 20,
    paddingBottom: 20,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  title: {
    fontSize: 32,
    fontFamily: 'Poppins-SemiBold',
    color: '#F7FAFC',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#CBD5E0',
    lineHeight: 24,
  },
  addButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#81E6D9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  statsContainer: {
    marginBottom: 30,
  },
  statsTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-Medium',
    color: '#F7FAFC',
    marginBottom: 16,
  },
  statsGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  statPercentage: {
    fontSize: 20,
    fontFamily: 'Poppins-SemiBold',
    color: '#F7FAFC',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#CBD5E0',
    marginTop: 4,
  },
  entriesContainer: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Poppins-Medium',
    color: '#F7FAFC',
    marginBottom: 16,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyStateTitle: {
    fontSize: 20,
    fontFamily: 'Poppins-Medium',
    color: '#F7FAFC',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyStateText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#CBD5E0',
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 24,
  },
  emptyStateButton: {
    backgroundColor: '#81E6D9',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 24,
  },
  emptyStateButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#2D3748',
  },
  entriesList: {
    gap: 12,
  },
  entryCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 16,
  },
  entryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  entryMood: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  entryDate: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#CBD5E0',
    marginLeft: 8,
  },
  deleteButton: {
    padding: 4,
  },
  entryTitle: {
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
    color: '#F7FAFC',
    marginBottom: 8,
  },
  entryContent: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#CBD5E0',
    lineHeight: 20,
    marginBottom: 8,
  },
  gratitudePreview: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  gratitudeText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#F56565',
    marginLeft: 6,
  },
  // Modal styles
  modalContainer: {
    flex: 1,
  },
  modalSafeArea: {
    flex: 1,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  modalCancelText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#FC8181',
  },
  modalTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-Medium',
    color: '#F7FAFC',
  },
  modalSaveText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#81E6D9',
  },
  modalContent: {
    flex: 1,
    paddingHorizontal: 20,
  },
  modalSection: {
    marginTop: 24,
  },
  modalSectionTitle: {
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
    color: '#F7FAFC',
    marginBottom: 12,
  },
  modalSectionSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#CBD5E0',
    marginBottom: 16,
  },
  moodSelector: {
    flexDirection: 'row',
    gap: 12,
  },
  moodOption: {
    flex: 1,
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  moodOptionSelected: {
    backgroundColor: '#81E6D9',
  },
  moodOptionText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#CBD5E0',
    marginTop: 8,
  },
  moodOptionTextSelected: {
    color: '#2D3748',
  },
  titleInput: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#F7FAFC',
  },
  contentInput: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#F7FAFC',
    minHeight: 120,
  },
  gratitudeItem: {
    marginBottom: 16,
  },
  gratitudePrompt: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#F6AD55',
    marginBottom: 8,
  },
  gratitudeInput: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#F7FAFC',
  },
});