import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Dimensions,
  Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Audio } from 'expo-av';
import {
  Play,
  Pause,
  Volume2,
  CloudRain,
  Waves,
  TreePine,
  Wind,
  Flame,
  Music,
  Coffee,
  Moon,
} from 'lucide-react-native';

const { width } = Dimensions.get('window');

interface SoundTrack {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  category: 'nature' | 'ambient' | 'focus';
  duration: string;
  // In a real app, these would be actual audio file URLs
  audioUrl: string;
}

export default function SoundsScreen() {
  const [currentTrack, setCurrentTrack] = useState<SoundTrack | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [sound, setSound] = useState<Audio.Sound | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'nature' | 'ambient' | 'focus'>('all');

  const soundTracks: SoundTrack[] = [
    {
      id: 'rain',
      name: 'Gentle Rain',
      description: 'Soft rainfall for deep relaxation',
      icon: <CloudRain size={24} color="#81E6D9" />,
      color: '#81E6D9',
      category: 'nature',
      duration: '60 min',
      audioUrl: 'https://example.com/rain.mp3', // Placeholder URL
    },
    {
      id: 'ocean',
      name: 'Ocean Waves',
      description: 'Rhythmic waves on a peaceful shore',
      icon: <Waves size={24} color="#4299E1" />,
      color: '#4299E1',
      category: 'nature',
      duration: '45 min',
      audioUrl: 'https://example.com/ocean.mp3',
    },
    {
      id: 'forest',
      name: 'Forest Ambiance',
      description: 'Birds chirping in a serene forest',
      icon: <TreePine size={24} color="#68D391" />,
      color: '#68D391',
      category: 'nature',
      duration: '30 min',
      audioUrl: 'https://example.com/forest.mp3',
    },
    {
      id: 'wind',
      name: 'Mountain Wind',
      description: 'Gentle breeze through mountain peaks',
      icon: <Wind size={24} color="#A0AEC0" />,
      color: '#A0AEC0',
      category: 'nature',
      duration: '40 min',
      audioUrl: 'https://example.com/wind.mp3',
    },
    {
      id: 'fireplace',
      name: 'Cozy Fireplace',
      description: 'Crackling fire for warmth and comfort',
      icon: <Flame size={24} color="#F6AD55" />,
      color: '#F6AD55',
      category: 'ambient',
      duration: '50 min',
      audioUrl: 'https://example.com/fireplace.mp3',
    },
    {
      id: 'piano',
      name: 'Peaceful Piano',
      description: 'Soft piano melodies for meditation',
      icon: <Music size={24} color="#9F7AEA" />,
      color: '#9F7AEA',
      category: 'ambient',
      duration: '35 min',
      audioUrl: 'https://example.com/piano.mp3',
    },
    {
      id: 'cafe',
      name: 'Coffee Shop',
      description: 'Ambient cafe sounds for focus',
      icon: <Coffee size={24} color="#D69E2E" />,
      color: '#D69E2E',
      category: 'focus',
      duration: '90 min',
      audioUrl: 'https://example.com/cafe.mp3',
    },
    {
      id: 'night',
      name: 'Night Sounds',
      description: 'Crickets and gentle night ambiance',
      icon: <Moon size={24} color="#805AD5" />,
      color: '#805AD5',
      category: 'ambient',
      duration: '120 min',
      audioUrl: 'https://example.com/night.mp3',
    },
  ];

  const categories = [
    { id: 'all', name: 'All Sounds' },
    { id: 'nature', name: 'Nature' },
    { id: 'ambient', name: 'Ambient' },
    { id: 'focus', name: 'Focus' },
  ];

  const filteredTracks = selectedCategory === 'all' 
    ? soundTracks 
    : soundTracks.filter(track => track.category === selectedCategory);

  useEffect(() => {
    return sound
      ? () => {
          sound.unloadAsync();
        }
      : undefined;
  }, [sound]);

  const playSound = async (track: SoundTrack) => {
    try {
      if (sound) {
        await sound.unloadAsync();
      }

      // In a real app, you would load actual audio files
      // For demo purposes, we'll simulate audio playback
      if (Platform.OS === 'web') {
        // Web doesn't support actual audio playback in this demo
        setCurrentTrack(track);
        setIsPlaying(true);
        return;
      }

      const { sound: newSound } = await Audio.Sound.createAsync(
        { uri: track.audioUrl },
        { shouldPlay: true, isLooping: true }
      );
      
      setSound(newSound);
      setCurrentTrack(track);
      setIsPlaying(true);
    } catch (error) {
      console.log('Error playing sound:', error);
      // Fallback for demo - just set the UI state
      setCurrentTrack(track);
      setIsPlaying(true);
    }
  };

  const pauseSound = async () => {
    if (sound) {
      await sound.pauseAsync();
    }
    setIsPlaying(false);
  };

  const resumeSound = async () => {
    if (sound) {
      await sound.playAsync();
    }
    setIsPlaying(true);
  };

  const stopSound = async () => {
    if (sound) {
      await sound.stopAsync();
      await sound.unloadAsync();
      setSound(null);
    }
    setCurrentTrack(null);
    setIsPlaying(false);
  };

  return (
    <LinearGradient colors={['#2D3748', '#4A5568', '#718096']} style={styles.container}>
      <SafeAreaView style={styles.safeArea}>
        <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
          {/* Header */}
          <View style={styles.header}>
            <Text style={styles.title}>Soothing Sounds</Text>
            <Text style={styles.subtitle}>
              Immerse yourself in calming soundscapes
            </Text>
          </View>

          {/* Category Filter */}
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            style={styles.categoriesContainer}
            contentContainerStyle={styles.categoriesContent}
          >
            {categories.map((category) => (
              <TouchableOpacity
                key={category.id}
                style={[
                  styles.categoryButton,
                  selectedCategory === category.id && styles.categoryButtonActive
                ]}
                onPress={() => setSelectedCategory(category.id as any)}
              >
                <Text
                  style={[
                    styles.categoryButtonText,
                    selectedCategory === category.id && styles.categoryButtonTextActive
                  ]}
                >
                  {category.name}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          {/* Sound Tracks */}
          <View style={styles.tracksContainer}>
            {filteredTracks.map((track) => (
              <TouchableOpacity
                key={track.id}
                style={[
                  styles.trackCard,
                  currentTrack?.id === track.id && styles.trackCardActive
                ]}
                onPress={() => {
                  if (currentTrack?.id === track.id) {
                    if (isPlaying) {
                      pauseSound();
                    } else {
                      resumeSound();
                    }
                  } else {
                    playSound(track);
                  }
                }}
              >
                <View style={styles.trackInfo}>
                  <View style={[styles.trackIcon, { backgroundColor: `${track.color}20` }]}>
                    {track.icon}
                  </View>
                  <View style={styles.trackDetails}>
                    <Text style={styles.trackName}>{track.name}</Text>
                    <Text style={styles.trackDescription}>{track.description}</Text>
                    <Text style={styles.trackDuration}>{track.duration}</Text>
                  </View>
                </View>
                <View style={styles.trackControls}>
                  {currentTrack?.id === track.id && isPlaying ? (
                    <Pause size={24} color={track.color} />
                  ) : (
                    <Play size={24} color={track.color} />
                  )}
                </View>
              </TouchableOpacity>
            ))}
          </View>

          {/* Tips */}
          <View style={styles.tipsContainer}>
            <Text style={styles.tipsTitle}>Listening Tips</Text>
            <View style={styles.tipsList}>
              <Text style={styles.tipItem}>• Use headphones for the best experience</Text>
              <Text style={styles.tipItem}>• Set a comfortable volume level</Text>
              <Text style={styles.tipItem}>• Close your eyes and focus on the sounds</Text>
              <Text style={styles.tipItem}>• Combine with breathing exercises</Text>
              <Text style={styles.tipItem}>• Create a quiet, comfortable environment</Text>
            </View>
          </View>
        </ScrollView>

        {/* Now Playing Bar */}
        {currentTrack && (
          <View style={styles.nowPlayingBar}>
            <LinearGradient
              colors={['rgba(45, 55, 72, 0.95)', 'rgba(74, 85, 104, 0.95)']}
              style={styles.nowPlayingGradient}
            >
              <View style={styles.nowPlayingInfo}>
                <View style={[styles.nowPlayingIcon, { backgroundColor: `${currentTrack.color}20` }]}>
                  {currentTrack.icon}
                </View>
                <View style={styles.nowPlayingDetails}>
                  <Text style={styles.nowPlayingName}>{currentTrack.name}</Text>
                  <Text style={styles.nowPlayingStatus}>
                    {isPlaying ? 'Playing' : 'Paused'}
                  </Text>
                </View>
              </View>
              <View style={styles.nowPlayingControls}>
                <TouchableOpacity
                  style={styles.nowPlayingButton}
                  onPress={isPlaying ? pauseSound : resumeSound}
                >
                  {isPlaying ? (
                    <Pause size={20} color="#F7FAFC" />
                  ) : (
                    <Play size={20} color="#F7FAFC" />
                  )}
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.nowPlayingButton}
                  onPress={stopSound}
                >
                  <Volume2 size={20} color="#F7FAFC" />
                </TouchableOpacity>
              </View>
            </LinearGradient>
          </View>
        )}
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 20,
  },
  header: {
    paddingTop: 20,
    paddingBottom: 20,
  },
  title: {
    fontSize: 32,
    fontFamily: 'Poppins-SemiBold',
    color: '#F7FAFC',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#CBD5E0',
    lineHeight: 24,
  },
  categoriesContainer: {
    marginBottom: 20,
  },
  categoriesContent: {
    paddingRight: 20,
  },
  categoryButton: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    marginRight: 12,
  },
  categoryButtonActive: {
    backgroundColor: '#81E6D9',
  },
  categoryButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#CBD5E0',
  },
  categoryButtonTextActive: {
    color: '#2D3748',
  },
  tracksContainer: {
    gap: 12,
    marginBottom: 30,
  },
  trackCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  trackCardActive: {
    backgroundColor: 'rgba(129, 230, 217, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(129, 230, 217, 0.3)',
  },
  trackInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  trackIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  trackDetails: {
    flex: 1,
  },
  trackName: {
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
    color: '#F7FAFC',
    marginBottom: 4,
  },
  trackDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#CBD5E0',
    marginBottom: 2,
  },
  trackDuration: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#A0AEC0',
  },
  trackControls: {
    padding: 8,
  },
  tipsContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 16,
    padding: 20,
    marginBottom: 100,
  },
  tipsTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-Medium',
    color: '#F7FAFC',
    marginBottom: 16,
  },
  tipsList: {
    gap: 8,
  },
  tipItem: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#CBD5E0',
    lineHeight: 20,
  },
  nowPlayingBar: {
    position: 'absolute',
    bottom: 70,
    left: 20,
    right: 20,
    borderRadius: 16,
    overflow: 'hidden',
  },
  nowPlayingGradient: {
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  nowPlayingInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  nowPlayingIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  nowPlayingDetails: {
    flex: 1,
  },
  nowPlayingName: {
    fontSize: 14,
    fontFamily: 'Poppins-Medium',
    color: '#F7FAFC',
    marginBottom: 2,
  },
  nowPlayingStatus: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#81E6D9',
  },
  nowPlayingControls: {
    flexDirection: 'row',
    gap: 12,
  },
  nowPlayingButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
});