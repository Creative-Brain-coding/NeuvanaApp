import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  Heart,
  Headphones,
  BookOpen,
  Sun,
  Moon,
  Smile,
  Meh,
  Frown,
  Calendar,
  TrendingUp,
} from 'lucide-react-native';
import { router } from 'expo-router';

const { width } = Dimensions.get('window');

interface MoodEntry {
  date: string;
  mood: 'happy' | 'neutral' | 'sad';
  score: number;
}

export default function HomeScreen() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [todayMood, setTodayMood] = useState<MoodEntry | null>(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);

    return () => clearInterval(timer);
  }, []);

  const getGreeting = () => {
    const hour = currentTime.getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  const getGreetingIcon = () => {
    const hour = currentTime.getHours();
    if (hour < 12) return <Sun size={24} color="#F6E05E" />;
    if (hour < 17) return <Sun size={24} color="#F6AD55" />;
    return <Moon size={24} color="#9F7AEA" />;
  };

  const quickActions = [
    {
      title: '5-Min Breathing',
      subtitle: 'Quick relaxation',
      icon: <Heart size={28} color="#81E6D9" />,
      onPress: () => router.push('/breathe'),
      gradient: ['#2D3748', '#4A5568'],
    },
    {
      title: 'Nature Sounds',
      subtitle: 'Peaceful ambiance',
      icon: <Headphones size={28} color="#68D391" />,
      onPress: () => router.push('/sounds'),
      gradient: ['#2D3748', '#4A5568'],
    },
    {
      title: 'Daily Journal',
      subtitle: 'Reflect & grow',
      icon: <BookOpen size={28} color="#9F7AEA" />,
      onPress: () => router.push('/journal'),
      gradient: ['#2D3748', '#4A5568'],
    },
  ];

  const moodOptions = [
    { mood: 'happy' as const, icon: Smile, color: '#68D391', label: 'Great' },
    { mood: 'neutral' as const, icon: Meh, color: '#F6AD55', label: 'Okay' },
    { mood: 'sad' as const, icon: Frown, color: '#FC8181', label: 'Tough' },
  ];

  const handleMoodSelect = (mood: 'happy' | 'neutral' | 'sad', score: number) => {
    const entry: MoodEntry = {
      date: new Date().toISOString().split('T')[0],
      mood,
      score,
    };
    setTodayMood(entry);
  };

  return (
    <LinearGradient colors={['#2D3748', '#4A5568', '#718096']} style={styles.container}>
      <SafeAreaView style={styles.safeArea}>
        <ScrollView showsVerticalScrollIndicator={false} style={styles.scrollView}>
          {/* Header */}
          <View style={styles.header}>
            <View style={styles.greetingContainer}>
              {getGreetingIcon()}
              <Text style={styles.greeting}>{getGreeting()}</Text>
            </View>
            <Text style={styles.subtitle}>How are you feeling today?</Text>
          </View>

          {/* Daily Mood Check */}
          <View style={styles.moodSection}>
            <Text style={styles.sectionTitle}>Today's Mood</Text>
            {!todayMood ? (
              <View style={styles.moodSelector}>
                {moodOptions.map(({ mood, icon: Icon, color, label }) => (
                  <TouchableOpacity
                    key={mood}
                    style={styles.moodOption}
                    onPress={() => handleMoodSelect(mood, mood === 'happy' ? 8 : mood === 'neutral' ? 5 : 3)}
                  >
                    <Icon size={32} color={color} />
                    <Text style={[styles.moodLabel, { color }]}>{label}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            ) : (
              <View style={styles.moodSelected}>
                <View style={styles.moodSelectedContent}>
                  {moodOptions.find(m => m.mood === todayMood.mood) && (
                    <>
                      {React.createElement(
                        moodOptions.find(m => m.mood === todayMood.mood)!.icon,
                        { size: 24, color: moodOptions.find(m => m.mood === todayMood.mood)!.color }
                      )}
                      <Text style={styles.moodSelectedText}>
                        Feeling {moodOptions.find(m => m.mood === todayMood.mood)!.label} today
                      </Text>
                    </>
                  )}
                </View>
                <TouchableOpacity onPress={() => setTodayMood(null)}>
                  <Text style={styles.changeMoodText}>Change</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>

          {/* Quick Actions */}
          <View style={styles.quickActionsSection}>
            <Text style={styles.sectionTitle}>Quick Actions</Text>
            <View style={styles.quickActionsGrid}>
              {quickActions.map((action, index) => (
                <TouchableOpacity
                  key={index}
                  style={styles.quickActionCard}
                  onPress={action.onPress}
                >
                  <LinearGradient
                    colors={action.gradient}
                    style={styles.quickActionGradient}
                  >
                    <View style={styles.quickActionIcon}>
                      {action.icon}
                    </View>
                    <Text style={styles.quickActionTitle}>{action.title}</Text>
                    <Text style={styles.quickActionSubtitle}>{action.subtitle}</Text>
                  </LinearGradient>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* Daily Inspiration */}
          <View style={styles.inspirationSection}>
            <Text style={styles.sectionTitle}>Daily Inspiration</Text>
            <View style={styles.inspirationCard}>
              <Text style={styles.inspirationQuote}>
                "Peace comes from within. Do not seek it without."
              </Text>
              <Text style={styles.inspirationAuthor}>- Buddha</Text>
            </View>
          </View>

          {/* Progress Overview */}
          <View style={styles.progressSection}>
            <Text style={styles.sectionTitle}>Your Progress</Text>
            <View style={styles.progressGrid}>
              <View style={styles.progressCard}>
                <Calendar size={24} color="#81E6D9" />
                <Text style={styles.progressNumber}>7</Text>
                <Text style={styles.progressLabel}>Days Active</Text>
              </View>
              <View style={styles.progressCard}>
                <TrendingUp size={24} color="#68D391" />
                <Text style={styles.progressNumber}>12</Text>
                <Text style={styles.progressLabel}>Sessions</Text>
              </View>
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 20,
  },
  header: {
    paddingTop: 20,
    paddingBottom: 30,
  },
  greetingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  greeting: {
    fontSize: 28,
    fontFamily: 'Poppins-SemiBold',
    color: '#F7FAFC',
    marginLeft: 12,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#CBD5E0',
    marginTop: 4,
  },
  moodSection: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Poppins-Medium',
    color: '#F7FAFC',
    marginBottom: 16,
  },
  moodSelector: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 20,
  },
  moodOption: {
    alignItems: 'center',
    padding: 16,
  },
  moodLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    marginTop: 8,
  },
  moodSelected: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 20,
  },
  moodSelectedContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  moodSelectedText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#F7FAFC',
    marginLeft: 12,
  },
  changeMoodText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#81E6D9',
  },
  quickActionsSection: {
    marginBottom: 30,
  },
  quickActionsGrid: {
    gap: 16,
  },
  quickActionCard: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  quickActionGradient: {
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
  },
  quickActionIcon: {
    marginRight: 16,
  },
  quickActionTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-Medium',
    color: '#F7FAFC',
    flex: 1,
  },
  quickActionSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#CBD5E0',
    marginTop: 2,
  },
  inspirationSection: {
    marginBottom: 30,
  },
  inspirationCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
  },
  inspirationQuote: {
    fontSize: 18,
    fontFamily: 'Poppins-Regular',
    color: '#F7FAFC',
    textAlign: 'center',
    lineHeight: 26,
    marginBottom: 12,
  },
  inspirationAuthor: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#81E6D9',
  },
  progressSection: {
    marginBottom: 30,
  },
  progressGrid: {
    flexDirection: 'row',
    gap: 16,
  },
  progressCard: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
  },
  progressNumber: {
    fontSize: 32,
    fontFamily: 'Poppins-SemiBold',
    color: '#F7FAFC',
    marginTop: 8,
  },
  progressLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#CBD5E0',
    marginTop: 4,
  },
});